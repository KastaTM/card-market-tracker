# Initial threat model

## P8d proposed delivery boundary (2026-10-30)

Historical P8c previews are not current consent. Proposed review/prepare binds
explicit synthetic-history acknowledgement to exact alert/signal/revision,
message/evidence digests and immutable private route. Source-backed admission,
consistent pair reads and one-use instance/content/operation/Budget authority
guard caller forgery; they do not authenticate a malicious host administrator.

Separate CMTZ ledger checks complete retained watch/revision equality under
prepare/claim transactions. Durable claim precedes HTTP and owner/state CAS
fences competing/late workers. Uncertain and unfinalized in_flight cannot resend.
Global quarantine is checked before replay and is durable before restore
publication, including entries absent from an old backup. No quarantine bypass.

Lazy offline imports/token denial, bounded redacted DTO/log projections,
unchanged supervised P8b transport, aggregate origin deadline and shared
finalization reserve require future falsification tests. These are proposed
controls, not runtime evidence. Trusted ancestors/ACLs, single ledger,
maintained UTC, capacity and physical Pi durability remain existing limitations;
TD-001..005 remain OPEN. [SEC design review](../phases/P8D_SECURITY_DESIGN_REVIEW.md),
[ADR0015](../adr/0015-manual-watchlist-telegram-delivery.md) and
[runbook](../runbooks/WATCHLIST_TELEGRAM_DELIVERY.md) define review scope.
LIVE Telegram remains unauthorized.

## P8c Watchlist preview boundaries (2026-10-27)

Original manifest/revision admission and one deeply verified journal snapshot
prevent caller DTO/hash/verified authority. A content/instance/Budget-bound one-use
receipt protects ordinary application calls, not privileged Python. Independent
CMTY exact inventory, guarded cells, canonical documents, reconstructed semantics
and immutable triggers detect invalid rehashed content. BEGIN IMMEDIATE commits
dedup/replay atomically. Historical simulation is not current notification consent.

Fresh-process Telegram-import/socket guards cover help/errors/commands. Logs
exclude IDs, aliases, evidence, prices, messages, paths, SQL and exceptions.
Explicit stdout/backups/preferences remain private operator data. Shared2/max5s
cooperative deadlines and byte/page caps fail closed without partial verify.
Three independent folds precede recovery publication; compensation removes only
safe owned links and preserves foreign/sidecar evidence. Complete commit/
publication may precede a failed response; exact replay/verify resolves it.

Trusted ancestors/ACLs, capacity, native Pi durability, privileged rewrites and
lack of global three-store atomicity retain existing limitations; TD-001..005
remain OPEN. No transport, credentials, new debt or quarantine bypass is added.

## P5b journal boundaries (2026-10-24)

The new CMTQ journal alone retains bounded normalized synthetic samples and
immutable P5a revision snapshots. Full original manifest admission and exact
revision reread prevent caller verdict/DTO authority. Storage reparses/recalculates
inputs and derives signals under BEGIN IMMEDIATE; replay never moves head.
Cross-series immutable revision equality, unique current sample, exact previous,
time/as_of monotonicity and per-rule freshness constrain false episode signals.
Deep verify reconstructs snapshots, results, complete fold and heads, detecting
inconsistency even after local hashes are recalculated. Original-backed recompute
is separate. Hashes/provenance declarations authenticate no commercial source or
privileged consistent rewrite; no distributed origin/journal atomicity exists.

Trusted directories, inode/link/sidecar checks and exclusive provisional verified
recovery protect ordinary local paths; preserve evidence on error. Synthetic
preferences/samples/stdout/backups need host ACLs. Default2s/max5s cooperative
deadlines, byte/node/depth/page caps and exact SQL inventory bound ordinary work;
blocked OS/device calls and hostile administrator ancestor races remain outside
guarantees (TD-003). Capacity/retention and native Pi power-loss qualification
remain TD-004/TD-002. All TD-001..005 stay OPEN. No product sockets, destination,
outbox bridge, scheduler or delivery authority is added; restore touches only
this history as of backup time, without changing Telegram quarantine.

Development tooling remains a supply-chain boundary. Initial P5b Linux CI found
CVE-2026-112940 in transitive filelock4.0.12 despite a passing local audit; the
narrow lock update to4.2.1 follows the maintainer advisory, without adding runtime
dependencies or suppressing findings. A local audit alone cannot override a
different applicable CI result; the corrected candidate requires all gates again.

## P5a watchlist boundaries (2026-10-23)

Assets are canonical targets, private operator preferences, immutable revision/
request history and backup copies. Host authorization, trusted directories and
ACLs control access; no multiuser service, credential, listener, collector or
transport is introduced. Product Internet calls, including Telegram, are zero.
Query stdout intentionally contains preferences/identity and must be protected;
logs admit only fixed operations/categories/results, duration and bounded counts.

Complete manifest parsing at public add/update/evaluate boundaries prevents UUID
syntax or fabricated dataclasses from bypassing curated membership. Exact parent
closure preserves language/variant/null/unknown and detects retargeting under an
existing CMT ID. Names and external aliases have no authority. Canonical hashes
test local equivalence, not independent curator or privileged-host authenticity.
Synthetic provenance is an operator declaration: reviewed authored fixtures are
required; relabeling real data creates no authorization or provenance proof.

Strict JSON/type/amount/token/time limits constrain hostile evidence. Validate
context, supplied previous ordering and future timestamps before disabled SKIPPED.
Required freshness precedes stock decisions. Explicit as_of and pure evaluation
exclude hidden clock, source IO and mutations. Samples/results/observed prices
never enter SQLite and MATCH creates no event or notification authority.

Exact owner/schema/inventory checks, parameterized SQL, scalar guards and deep
canonical/history/request/current validation detect accidental/hostile local
inconsistency. BEGIN IMMEDIATE and expected-revision CAS prevent lost updates;
complete command replay prevents token reuse conflicts and old replay rollback.
The manifest read and SQLite commit are separate operations without distributed
atomicity. A coherent administrator rewrite is outside authentication guarantees.

One shared default2s/max5s budget, bounded pages and byte caps constrain ordinary
work; blocked OS/device calls remain outside cooperative deadlines. Trusted
ancestor/inode/sidecar checks and exclusive copy destinations prevent ordinary
path collisions; hostile ancestor races/Windows ACLs remain TD-003. Backup and
restore fully verify a consistent copy before exposing a new destination; never
delete valid journals, overwrite existing targets or alter earlier databases.
History growth/copy headroom (TD-004) and native Pi electrical durability (TD-002)
remain open, along with all TD-001..TD-005 owners/exits. No P5a gate is certified
by this analysis; independent QA/REVIEWER must test the final SHA/tree.

## P8b delivery boundaries (2026-10-21)

Private ownership requires operator attestation plus getMe/getChat identity
verification; API access alone proves no human ownership. Route is immutable.
Provider/event and provider/alert uniqueness resist route-change duplicates.
Each attempt repeats original-capture proof and freezes exact P8a message bytes.

Claim commits before HTTP; attempt ownership and CAS fence stale finishers.
Explicit quiescence recovery only yields uncertain. Crash/ambiguous success/
timeout/5xx/failed receipt commit never authorize resend. This can omit alerts;
it is not exactly-once. Old backups may omit later sends, so every restore is
globally quarantined, including absent rows. Only already-quarantined staging
content reaches the final restore path. A single trusted ledger is required;
arbitrary external clones are not coordinated.

Tokens stay in local environment; never arguments/DB/results/logs. Fixed official
TLS, no inherited proxy/redirect/retries, 64KiB strict UTF8/JSON/depth/types and
exact sender/recipient/text/date checks constrain untrusted HTTP. Raw provider
bodies/exceptions never cross worker IPC. Supervision bounds stalled DNS/drip/
reads with bounded cleanup overhead. Logs and ordinary CLI stdout exclude
bot/chat IDs, message text, secrets, authenticated URLs and raw exceptions.

Trusted directories/ACLs, correct UTC for cooldown, capacity, OS/device IO stalls,
privileged tampering and native Pi power loss remain limitations. TD-001..TD-005
stay OPEN. Fake tests cannot prove live acceptance; T17 needs specific operator
authorization and observed receipt/replay. The qualification wrapper observes
production entry calls and reserves its one-attempt evidence before network.

## P8a offline outbox boundaries (2026-10-20)

The new assets are logical destination aliases, immutable pending intentions,
plain text previews and complete per-comparison evidence. Anyone with local
read access can inspect these and stdout/backups; private directories and host
ACLs remain the authorization boundary. No contacts, credentials or transport
are introduced. Historical future Telegram assignments below do not authorize it.

Journal self-consistency is insufficient admission: retain one complete pair,
recompute from original verified captures with the unchanged comparator, require
full canonical equality and bind every consumed field into a private receipt.
That boundary rejects caller declarations and later mutation but is not a
signature against privileged Python. Sources are read-only snapshots; origin
verification precedes outbox commit and assumes immutable source evidence.
Coherent administrator replacement of all sources is outside authentication.

Exact CMTA ownership/schema, bounded SQL scalar guards before materialization,
strict JSON/identity/digest/renderer checks and parent/evidence correspondence
detect local inconsistencies. BEGIN IMMEDIATE, unique event/destination and
alert/comparison keys provide atomic deduplication, replay and conflict rollback.
SQLite handles process-interruption recovery; never delete sidecars or silently
repair records. Copy into exclusively reserved targets, validate and reopen.

Renderer escapes controls, line breaks, bidi and nonprintable input, caps UTF-8
messages at4096 bytes, labels synthetic/candidates and qualifies selected-window
novelty. It fabricates no names, URLs or commercial facts. Original values remain
in frozen evidence. Structured logs allow only fixed operation/category/result,
run ID, duration and bounded counts, excluding destinations, messages, references,
paths, SQL and raw exceptions. Explicit stdout remains protected untrusted data.

One comparison/1000 events/16MiB preparation, bounded summary pages and one
cooperative2s budget (explicit max5s) limit ordinary work. Timeout is failure,
never partial PASS; blocked OS IO remains outside hard deadline guarantees.
Trusted-directory races, global capacity, legacy scope and native Pi durability
remain TD-001 through TD-005. See [the recovery runbook](../runbooks/ALERT_OUTBOX_RECOVERY.md)
and [phase evidence](../phases/P8A_OFFLINE_ALERT_OUTBOX.md) for executed checks.

## P4c journal boundaries (2026-10-19)

Public admission accepts only strict v3 requests plus original verified capture
DB and independent journal paths. The application seals bounded canonical bytes
only after the unchanged snapshot reader/comparator path. Storage revalidates
the receipt and full semantic grammar. This resists ordinary constructor/flag/
JSON admission forgery, not privileged code in the same process. The comparator
and source registry/guards remain unchanged; acquisition budget is zero.

The journal's own owner/application_id/schema1/exact inventory prevents accidental
capture DB conversion. Atomic comparison+occurrences, composite occurrence keys,
content comparison on replay/conflict and preserved first insertion prevent
partial or falsely globally deduplicated evidence. DELETE/FULL and rollback
recovery do not authenticate hardware or establish physical power-loss resistance.

SQL type/byte guards cover schema/scalar/payload fields before materialization.
Strict finite/duplicate-aware bounded JSON and full nested grammar protect local
verification from coherently hashed invalid input; ASCII canonical comparison
distinguishes bool from int. A coherent valid rewrite can still pass local verify;
source recompute is a separate read-only check against original captures. Neither
can authenticate an administrator controlling both files.

Per-result16MiB before copying, page1MiB/keyset100 default1000 max, original
request/history/event limits and one shared2s/default5s/max budget bound ordinary
work. Busy/progress and encoding/scan loops share the deadline. OS/device stalls
are outside cooperative bounds. Append-only growth still needs capacity monitoring
(TD-004); no retention/quota is introduced. A timed-out scan never means PASS.

Existing trusted-directory/link/hardlink/sidecar checks apply separately to both
files and recovery targets. New files are exclusively reserved; no existing
destination is overwritten. Backup holds a verified snapshot, copies via SQLite,
validates and reopens destination. No atomic two-file backup is claimed. Preserve
sidecars for engine recovery; never delete them to force success. TD-003 hostile
administrator/ancestor replacement and Windows ACL limits remain unchanged.

Logs contain only fixed operation/category/result, run ID, duration and bounded
counts; explicit stdout may contain sensitive local evidence. Protect it along
with DB/backups. Runtime remains offline, nonroot UID10001 in containers, with
readonly fixtures. TD-001 through TD-005 remain open with existing owners/exits.

## P1c reviewed pair boundaries (2026-10-18)

Exact whole-package registry locks resist third revisions, poisoned/minimized
packages, fake caller registries, self-asserted observed values and false clocks.
Every reader revalidates retained manifest/resolution/scope/rows against approved
package bytes before returning. Replay keeps acquisition identity; only the
profile-authorized compatibility key permits R0/R1 differences. V3 emits those
revisions/digests/times and the registry-reviewed eight-span extraction proof
explicitly, binds proof to the profile receipt and hashes full evidence. Producer engineering
timestamps remain local declarations, never externally authenticated timestamps.

Storage issues content-bound profile receipts only after complete reconstruction
inside one read-only transaction; dataclass construction/replacement grants no
authority. This boundary does not defend against arbitrary privileged Python
already executing in-process. Complete unselected-unit checks, lexical/byte limits,
33-batch/33000-row/1000-event limits and 2s/default5s/max budgets resist hidden
corruption, snapshot mixing and resource exhaustion. Failed evidence returns
error/counts null/events empty; zero discoveries says nothing about source health.

Preserve private trusted directories, journal handling, atomic writes, verified
new-destination recovery, owner UID10001, runtime network denial and strict log
allowlists. Logs contain fixed operations/categories/counts/duration/run ID, never
payload/names/paths/tokens/SQL/raw exceptions. Source bodies were temporary and
removed after independent QA and REVIEWER contrast; only licensed minimum/MIT,
locks/spans and ledger remain. No new credentials, endpoints or collector exist.

## P4b scoped read boundaries (2026-10-16)

Scope spoofing, false completeness by filtering, provenance-family mixing,
reimport redating, forged Python DTOs and divergent validation can create false
novelty. The v2 route uses strict bounded request parsing, one explicit read-only
transaction, P1b byte/lexical/envelope reconstruction and complete batch/identity
validation before selecting original unit indexes. Mode/evidence/provenance must
agree for every record, including units excluded from comparison. Legacy,
partial/failed, unsupported/mixed and selected rejected evidence fail safely.

Content-bound private storage receipts prevent ordinary constructor/replacement
claims of DB verification; this is a module boundary, not protection against
arbitrary code/administrators inside the process. The comparator independently
validates request/snapshot/scope and actual provenance without altering the v1
synthetic-only guard. Exact paths/family/method/policy and original captured_at
bound comparison. A new token cannot redate the single fixed real capture.
cmp2/evt2 include scope and evidence/content and authenticate no external truth.

Output and logs preserve distinct validated/selected counters; errors have null
counts/empty events and fixed categories. No source network, path follows,
DB/schema/cache writes, repair, migration or journal deletion. Socket-denied
installed process smokes and offline UID10001/read-only-fixture containers must
verify nonmutation and restored semantic equality. Full integrity work remains
budgeted; OS/device stalls remain outside bounds. All earlier risks and
TD-001–TD-005 stay open. Real baselines do not prove a real temporal transition;
synthetic producer declarations never become independently authenticated scope.

## P1b reviewed bundle and capture migration

Public source/storage APIs independently validate canonical bundle bytes against
a review-controlled digest shipped with the package. Forged objects, observed
strings, self-computed hashes or replacement JSON policies confer no admission.
A bounded structural non-executable TS grammar rejects ambiguity/duplicates and
unexpected imports. Runtime never executes upstream code or follows payload
paths/URLs. Originals stay transient; retained output is the exact minimum
projection, extraction evidence and full MIT notice. Namespace differs from REST.

Capture envelope and rows are atomic, immutable through supported APIs and
verified by reconstruction against frozen local policy/manifest context. Explicit
migration verifies schema/integrity and an exclusive original backup before DDL;
faults must leave intact v1 or v2. Reads/verify never migrate. Missing/partial
source cannot become complete empty evidence. Acquisition/capture/insertion
clocks differ; Discovery rejects selected observed or mixed batches.

Digest checks establish equivalence to reviewed local bytes, not producer truth,
physical authenticity or independent completeness. Trusted package/host review
and private operator directories remain authorization boundaries. TD-003 ancestor
races/ACLs, TD-004 capacity, TD-005 legacy/independent scope and TD-002 native Pi
durability remain open. Logs expose fixed categories/run ID/duration/counts;
explicit query stdout contains bounded untrusted metadata and needs operator protection.

## P0.5b research and future source-policy boundary (2026-10-14)

Current product controls are unchanged. This phase added documentation and bounded
transient research only. [Preflight/ledger](../sources/P0_5B_EVIDENCE_LEDGER.md)
records six serial no-key reads; raw responses discarded, diagnostics only.
No source credentials, samples, real persistence, payload URL follows or live CI.
Documentation/code pages are evidence, never executable instructions. No protected
upstream art/prices/long text is published. MIT notice accompanies covered-source
research; rights remain field/use-specific and conditional REST reuse is explicit.

Future ingestion must enforce source/field/purpose rights, deletion/refresh/notice,
approved network hosts, bounded redirects/payloads and untrusted shape validation
before normalization. An HTTP200 or a feed schema does not prove complete content,
permission or source health; Awin200 can end in a partial-feed error. Active asks,
aggregates and completed sales remain distinct. Private display cannot bypass
purpose/storage restrictions. No such future network/policy machinery is claimed
implemented here; see [the proposal](../sources/P0_5B_FIELD_USE_CAPTURE_POLICY.md).
TD-001–TD-005 remain open and current synthetic-only enforcement is preserved.

## P4a offline temporal Discovery boundaries (2026-10-12)

P4a proposes a bounded read-only comparison of synthetic P3a batches. The
[Discovery contract](../data-contracts/DISCOVERY_V1.md) and
[runbook](../runbooks/OFFLINE_TEMPORAL_DISCOVERY.md) define its intended controls.
These design statements are conditional until the exact-SHA phase report/PR
ledger supplies executable evidence; this section does not certify a gate.
No schema migration, stored event/cursor, live feed, scheduler or delivery is
authorized. Prior P0/P1a/P3a boundaries remain unchanged.

The strict request and public Python DTO boundaries must independently validate
all values; typed/frozen constructors confer no authority. Required limits are
1 MiB, depth16, nodes20,000, strings/keys1,024, at most32 unique earlier batches,
1,000 rows per batch, 33,000 total rows and 1,000 events. Booleans cannot stand
in for integer versions/counts. Duplicate keys, malformed IDs, wrong types,
unknown fields and excessive input must fail without partial/truncated success.
Exact namespace/kind/language, including null, must match every nonempty record;
variant remains part of the full reference. No name-based identity or SQL/URL
from input is permitted.

STORAGE_V1 has no independently persisted scope for empty batches. Their DB
metadata proves existence, counts and capture only. The four-field request's
exact context is the caller/producer attestation for each selected empty batch,
reported as `request_attested_empty`; nonempty evidence is `records_verified`
only after every record matches. The manifest/resolver `context_fingerprint`
is not a capture-scope proof. Wrong empty-scope declarations can generate false
novelty and cannot be detected from schema1 alone. Neither label, integrity check
nor hash authenticates an administrator or producer. This local trust compromise
is TD-005; durable independent scope needs a later Orchestrator decision.

One noncreating `mode=ro`/`query_only` SQLite connection and an explicit consistent
read transaction must cover schema/integrity, metadata and rows for all selected
batches. Parameterized SQL, path guards, one finite global budget, VM interruption,
lock deadlines and close/rollback protect ordinary work. OS/device calls that do
not return remain outside the deadline guarantee. Missing/foreign/future/corrupt
DBs, missing batches, invalid versions/enums/provenance, rejection counts,
metadata/row/index contradictions and timeouts are categorized failures, never
empty snapshots. Hot-journal recovery may require a separate authorized writable
operation; Discovery must neither repair nor delete journals.

The comparator must revalidate generic snapshots, freeze stored resolutions and
union accepted/candidate references across all selected history. Accepted other
kinds also suppress later candidate novelty. Identical within-batch duplicates
collapse; contradictory same-reference rows fail the whole operation even on a
baseline. Legitimate across-capture evolution remains historical evidence. No
re-resolution, automatic promotion, implicit latest lookup or global novelty is
allowed. No-history baseline, valid zero discoveries and failure stay distinct;
window-relative event hashes create no CMT identity and guarantee no delivery.

Stdout is minimal contracted untrusted evidence, without observation names/raw
payloads. Logs must allow only fixed categories/results, run ID/duration and
bounded counts, with failure counts unknown. Batch IDs, contextual references,
paths, SQL, payloads and raw exceptions stay out of stderr. Protected host access
and saved-output access remain operator responsibilities. Only authored synthetic
fixtures are admitted; the label proves neither provenance nor retention rights.

The container design retains UID/GID10001, checked private named-volume ownership,
offline data invocations and read-only fixture mounts. Evidence must seed and
compare in distinct invocations and verify full DB logical content, inventory,
version and backup/restore equivalence. These controls require executed wheel,
Compose and both architecture smokes; ARM64 QEMU is not native Pi/storage evidence.
Trusted-directory races, native interruption and append-only capacity remain
TD-003, TD-002 and TD-004 respectively; TD-001 diagnostic limits also remain.

## P3a synthetic persistence boundaries (2026-10-10)

P3a adds a local SQLite asset: immutable synthetic observation/resolution history,
curated identity projections, stable batch tokens and recovery copies. It adds no
credential, provider connection, exposed endpoint, scheduler or commercial feed.
The [persistence input](../data-contracts/PERSISTENCE_V1.md),
[storage contract](../data-contracts/STORAGE_V1.md) and
[runbook](../runbooks/OBSERVATION_STORAGE.md) define the boundaries. The phase
report/PR ledger supplies reproducible gate evidence tied to the reviewed SHA;
this description does not itself certify a gate or native Pi durability.

The public batch boundary reparses the full manifest and revalidates normalized
values, indexes and resolver correspondence before storage. A caller-created
dataclass or resolution ID is not authority. Exact contextual bindings determine
accepted targets and complete parents; candidates retain a reference and category
without a CMT ID. Rejections carry only indexed fixed categories, not raw evidence.
Programmatic `RecordError` values are categorical assertions by the local producer;
the discarded invalid payload cannot be independently reconstructed from them.

Synthetic provenance is checked before an observation can become a rejection.
`documented` and `observed` do not authorize retention. The synthetic label itself
is a local claim, so fixture review remains necessary. No images, prices, stock,
personal data, long provider text or ignored extras belong to retained snapshots.
The P1a byte/depth/node/string/record bounds are reused; P3a also bounds encoded
in-memory JSON and requires explicit zoned capture with UTC normalization and
capture disagreement errors. Capture, release, provider update and local first
batch persistence have separate meanings.

Replay binds ordered normalized evidence, duplicates, nulls, versions, targets,
safe rejection categories and sorted resolver context. Localization names and
binding audit reasons are excluded because they do not affect resolution;
unrelated identity/binding edits conservatively change context. A SHA256 digest
tests equivalence, creates no product identity and authenticates neither producer
nor curator. Changing a rejected raw payload while keeping its safe category is
equivalent because that payload is intentionally not retained. The producer must
preserve the UUIDv4 batch token to recognize a retry; a new token adds history.

Logs extend the existing fixed event/category/field allowlist. Names, input values,
references, SQL, paths, tokens, arbitrary extras and raw exception text stay out of
stderr. Failed operation counts are unknown, not a successful zero. Query stdout
intentionally carries normalized names/references; callers must treat it as
untrusted data and protect retained output. No SQL from input, dump execution or
extension loading is permitted by the storage boundary.

Host access remains the authorization boundary. A user who can modify the
manifest/database is a trusted administrator; neither integrity checks nor hashes
prove that history was authored honestly. Use private operator-controlled local
directories and owner-only data access. Portable pathname checks cannot confine
SQLite against a hostile concurrent ancestor replacement; Windows ACLs remain
the operator's responsibility. These limits and append-only capacity growth are
tracked as TD-003/TD-004. Native interruption/storage testing remains TD-002.

SQLite values use parameters and all query/ordering/schema fragments are internal
constants; no input SQL/dump or extension is executed. Owned application/version
markers and exact schema inventory prevent opening another/future/altered schema
as an empty CMT database. Connections explicitly enable/check foreign keys;
writes use explicit SQL transactions under Python 3.13 `autocommit=True`, with
DELETE journal and FULL synchronization. Rollback covers batch metadata,
identities and record snapshots; attempted counts are reported only after commit.
Process-failure and simulated-IO evidence must remain distinct from physical
power-loss evidence.

Reads open existing files in read-only/query-only mode and cannot create missing
databases. Limits are strict integers 1..1000 with fixed deterministic order.
The default two-second SQL/lock budget and VM interruption bound ordinary work;
the backup progress callback checks a shared budget between bounded page steps.
Unresponsive OS/device calls remain outside this deadline guarantee. Large
append-only history may require a later measured capacity/budget decision.

Path checks reject links, junctions/reparse points, linked ancestors, directories,
special files, unsafe local path forms and multiply-linked database files. New
database/copy destinations reserve a file exclusively with requested mode 0600.
Existing destination or sidecar collisions are rejected; existing valid journals
are preserved for SQLite recovery, with linked/nonregular sidecars rejected.
Copy failures clean only the reserved destination under the trusted-directory
assumption. Backup/restore use SQLite's consistent backup API into a new target,
checking source/result schema, integrity and FKs and reopening the result.
Integrity does not authenticate history or assess provider/host health.

Container data lives at explicit `/data`, built with UID/GID 10001 and mode 0700,
and uses a selected named volume. Data processing disables networking and mounts
fixtures read-only; the product still runs as UID 10001. Persistence evidence must
span distinct container invocations and verify actual mounted ownership. Existing
volume permissions are an operator responsibility and must not be bypassed with
root product execution, mode 777 or a writable whole-project mount.

The sections below preserve the P1a, P0 and P0.5 scopes as historical boundaries;
their statements that those slices have no database do not describe P3a.

## P1a implemented local catalog controls

Untrusted UTF-8 regular files are read with a 1 MiB limit. Strict parsing rejects
duplicate keys, malformed encodings, nonfinite numbers and excessive nesting;
structure, strings, batch size and manifest counts are bounded. No content is
executed and no URL is followed. JSON shape validation precedes normalization.
Only allowlisted metadata reaches generic observations, and output omits names,
images, price data and arbitrary provider extras. Minimal candidate references
are intentional stdout data; callers should treat stdout as untrusted metadata.

Canonical UUIDv4 IDs and typed relationships are validated in an explicit
read-only manifest. Contextual bindings must agree with entity kind, language,
variant and relationships; contradictions fail instead of merging. Unknowns
remain candidates and cannot promote themselves. No name-based matching exists.
This preserves deterministic replay without database mutation. A host user can
edit the manifest; its authorization is a local curator trust boundary, not a
cryptographic signature or multi-user approval workflow.

Logs allow only fixed categories, operation UUID/duration and bounded counts;
errors never serialize exception text, paths, raw input or arbitrary names.
There is no output-file option, credential, listener, production collector or
database. Compose and container catalog smoke have networking disabled and
read-only fixture mounts. Fixture retention is synthetic only; field-specific
real-data rights remain governed by the [policy](../sources/TCGDEX_P1A_FIELDS.md).
Dependency/secret scanning and independent exact-SHA QA/security review remain
mandatory gates. Physical Pi resource and interruption behavior stays unverified.

## Scope and assets

P0 handles local configuration, CLI output, build dependencies, CI, and a non-root one-shot container. It has no external source integration, business database, Telegram token, HTTP listener, or continuous service. Future valuable assets include credentials, historical observations, product identity, and notification channels.

## Trust boundaries and threats

| Boundary | Threat and impact | P0 control | Later owner/control |
| --- | --- | --- | --- |
| Local config / secrets | A path, token, or secret enters Git, an error, or logs. | Sanitized `.env.example`; local-file exclusions; config errors omit values; secret scan. | Future P8b, if authorized: Telegram secret injection, rotation, and delivery redaction. |
| Dependency / CI | Malicious or vulnerable package, workflow permission, or unreviewed lock update. | Frozen lock; no runtime deps; read-only workflow content permission; dependency audit and secret scan gates. | Each dependency update: review provenance, findings, and exceptions. |
| External provider -> domain | Malformed/poisoned price or identifier yields false value/opportunity. | No ingestion in P0; documented validation boundary. | P0.5/P1a/P2/P6a/P9: source approval, validation, provenance, anomaly handling, rate limits. |
| Pi host / network / storage | Unauthorized access, exposed ports, lost data after outage, or home-network attack. | Container UID 10001 and no published ports. | P3a/P9.5: file permissions, backup/restore, access policy, recovery and native Pi tests. |
| Future DB | Corruption, concurrent writes, stale backup, or unauthorized reads. | No DB in P0. | P3a/P9.5: schema/migration strategy, integrity checks, backup and restore drills. |
| Resource use | Runaway requests, memory, CPU, or disk usage harms Pi/provider. | P0 command exits; local temporary probe; no collector. | P0.5/P6a/P9.5: bounded work, timeout, rate limits, budgets, monitoring. |

The local CLI is callable by anyone with host access; host authorization is outside this package. `diagnose` confirms only config and local work-directory access. It cannot certify external source or system health. Future exposed endpoints require authentication and authorization analysis before implementation.

## Review rule

Treat a relevant scanner finding as a failed gate until corrected or documented in a narrow, reviewable exception with owner and expiry/revisit trigger. Broad ignores are not an acceptable substitute. Revisit this threat model when a phase adds secrets, providers, persistence, delivery, or a long-running service.

## P0.5 external-source assessment (2026-10-07)

P0.5 performed only bounded research and five unauthenticated TCGdex GETs; no production source adapter, credential, database, periodic job, or external-data display was added. The [source matrix](../sources/SOURCE_MATRIX.md) and [preliminary ingestion requirements](../data-contracts/SOURCE_INGESTION_V0.md) record future boundaries. A documented requirement below is **not** an implemented protection.

| Future boundary | Threat | Required later control and evidence |
| --- | --- | --- |
| Provider URL and redirect to network | Source-controlled links or unexpected redirects reach local/private services, leak headers, or leave approved hosts. | Approved HTTPS host list, controlled redirect chain, DNS/IP checks, no credential forwarding, timeout and response-size limits; test hostile URLs in the implementing phase. |
| Provider payload to normalized ingestion | Malformed JSON/HTML, huge responses, ambiguous currencies, poisoned prices, variant mismatch, and partial fields corrupt domain observations. | Bounded parsing, versioned validation, quarantine of unknown candidates, explicit nulls and price semantics, decimal bounds, provenance and incompatible-change tests. |
| API access and secrets | Tokens leak in URLs, logs, fixtures, CI, or a redirected request; access terms are exceeded. | Approved secret injection, least scope, redaction, rotation plan, per-source request budgets and rate-limit handling. P0.5 acquired no tokens. |
| License and durable history | Technically reachable listings are stored, combined, analyzed, or displayed beyond the provider's grant. | Per-source permission record covering access, storage duration, deletion, derived analytics and display before production retention. Unknown rights block persistence. |
| Discovery to identity and alerts | An unfamiliar SKU is forced onto a known product, or a stale/false stock state triggers a market alert. | Preserve unknown candidates and seller/offer distinctions; require identity review and time-scoped stock evidence. Market Alerts belong to later product phases; System Alerts for source failures belong to later operations. P0.5 records probe outcomes only. |

The three retailers' published or unreadable conditions did not establish permission for automated monitoring, so no direct retail probe was made. Cardmarket and eBay API endpoints were not probed without authorized production access. These abstentions are part of the evidence, not a claim of operational source health.
