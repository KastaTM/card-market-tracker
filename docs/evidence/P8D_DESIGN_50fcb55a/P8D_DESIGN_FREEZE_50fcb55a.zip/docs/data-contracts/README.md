# Data contract conventions

P8d proposes [Watchlist Telegram delivery v1](WATCHLIST_TELEGRAM_DELIVERY_V1.md)
and [independent storage v1](WATCHLIST_TELEGRAM_DELIVERY_STORAGE_V1.md).
These are review targets, not implemented schemas or new authority for prior
P8b/P8c routes. Phase Lead must accept the design before writer work.

P4b adds [Discovery v2](DISCOVERY_V2.md) as a separate read-only unit-selection
route over schema2 capture evidence, with compatible storage/capture read and
logging extensions. V1 remains synthetic-only. No schema or writer change.
Only the fixed P1b package is observed; positive temporal examples are synthetic.

P1b adds [reviewed pinned bundle v1](PINNED_REPOSITORY_BUNDLE_V1.md),
[capture scope v1](CAPTURE_SCOPE_V1.md) and [storage v2](STORAGE_V2.md).
Only the dedicated independently validated minimum package can admit observed
evidence; PERSISTENCE_V1 and Discovery remain synthetic-only. Explicit schema
migration preserves historical rows/fingerprints and marks old scope unverified.
Historical v1 boundaries and dated evolution notes below remain snapshots.

P4a adds [Discovery v1](DISCOVERY_V1.md), compatible STORAGE_V1 read snapshots
and allowlisted LOGGING_V1 fields. Schema1 remains unchanged. Empty scope is an
explicit caller/producer declaration, separated from stored existence/counts.

P3a adds [persistible synthetic input v1](PERSISTENCE_V1.md) and
[SQLite storage/read v1](STORAGE_V1.md), plus an additive allowlisted logging
extension. Required capture/synthetic-only retention apply at the new write
boundary; P1a's optional capture and read-only catalog contracts are unchanged.

P1a implements [catalog v1](CATALOG_V1.md), [ingestion v1](INGESTION_V1.md)
and [manifest v1](MANIFEST_V1.md), alongside the additive logging v1 extension.
Source ingestion v0 remains historical preliminary requirements for later
market/retail phases; it is not the P1a runtime contract.

Store contracts here as `NAME_VN.md`, where `N` is an integer major version. Describe producer, consumer, fields, types, semantics, errors, security/redaction, examples, and compatibility. A backward-compatible addition needs a documented optional field and tests. Removing or changing a required field, type, or meaning requires a new major version and a migration plan. Pin consumers to an explicit version.

The only implemented P0 data contract is [logging v1](LOGGING_V1.md). The future ingestion boundary is `External Source -> Validation -> Normalized Ingestion -> Domain`. Provider-specific contracts are deferred until source feasibility and adapter phases; no fictitious provider payloads are published.

Synthetic fixtures must be identified as synthetic. Future real fixtures must be minimal, sanitized, permitted to retain, and accompanied by source/provenance and date. See the [testing strategy](../TESTING_STRATEGY.md).

P1c: [bundle v2](PINNED_REPOSITORY_BUNDLE_V2.md) and [Discovery v3](DISCOVERY_V3.md) add explicit routes; prior contracts remain unchanged.
